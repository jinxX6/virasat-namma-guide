import React, { useState, useRef, useEffect } from 'react';
import { HeritageSite } from '../data/sites';
import { ChevronLeft, Play, Pause, MapPin, Info, BookOpen, Sparkles, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SiteDetailProps {
  site: HeritageSite;
  onClose: () => void;
  onCheckIn: (siteId: string) => void;
  isVisited: boolean;
  unlockedFact: boolean;
  language: 'en' | 'kn';
}

export default function SiteDetail({ 
  site, 
  onClose, 
  onCheckIn, 
  isVisited, 
  unlockedFact,
  language 
}: SiteDetailProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const toggleAudio = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-40 bg-heritage-sand overflow-y-auto"
    >
      {/* Header Image Section */}
      <div className="relative h-96 w-full">
        <img src={site.image} alt={site.name[language]} className="w-full h-full object-cover grayscale-[20%]" />
        <div className="absolute inset-0 bg-gradient-to-t from-heritage-stone via-heritage-stone/40 to-transparent" />
        
        <button 
          onClick={onClose}
          className="absolute top-6 left-6 p-3 bg-heritage-gold text-white rounded shadow-xl hover:scale-110 transition-transform z-10"
        >
          <ChevronLeft size={24} />
        </button>

        <div className="absolute bottom-12 left-8 right-8">
          <div className="flex items-center gap-3 text-heritage-gold mb-3 font-bold tracking-[0.2em] uppercase text-xs">
            <span className="px-3 py-1 bg-heritage-gold text-white rounded-full">Archive No. {site.id}</span>
            <div className="flex items-center gap-1">
              <MapPin size={14} />
              <span>{site.location}</span>
            </div>
          </div>
          <h1 className="font-serif text-4xl md:text-6xl text-white leading-tight mb-2 tracking-tight">
            {site.name[language]}
          </h1>
          <p className="text-heritage-sand/80 text-xl italic font-serif opacity-80">
            {language === 'en' ? 'Authentic Historical Record' : 'ಅಧಿಕೃತ ಐತಿಹಾಸಿಕ ದಾಖಲೆ'}
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-8 -mt-10 relative bg-heritage-sand shadow-2xl border-x border-heritage-muted min-h-screen">
        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12 border-b-2 border-heritage-muted pb-8">
          <button 
            onClick={toggleAudio}
            className="flex items-center justify-center gap-4 bg-heritage-stone text-heritage-sand px-8 py-4 rounded shadow-lg hover:bg-heritage-dark transition-colors font-bold uppercase tracking-[0.1em]"
          >
            {isPlaying ? <Pause size={20} /> : <Play size={20} />}
            <span>
              {isPlaying 
                ? (language === 'en' ? 'Pause Guide' : 'ವಿರಾಮಗೊಳಿಸಿ')
                : (language === 'en' ? 'Play Audio Guide' : 'ಆಡಿಯೋ ಮಾರ್ಗದರ್ಶಿ ಪ್ಲೇ ಮಾಡಿ')}
            </span>
            <audio ref={audioRef} src={site.audioUrl} onEnded={() => setIsPlaying(false)} />
          </button>

          <button 
            onClick={() => onCheckIn(site.id)}
            disabled={isVisited}
            className={`flex items-center justify-center gap-4 px-8 py-4 rounded shadow-lg transition-all border-2 font-bold uppercase tracking-[0.1em] ${
              isVisited 
                ? 'bg-heritage-gold text-white border-heritage-gold cursor-default' 
                : 'border-heritage-stone text-heritage-stone hover:bg-heritage-gold hover:text-white hover:border-heritage-gold'
            }`}
          >
            <div className="text-2xl">🛂</div>
            <span>
              {isVisited 
                ? (language === 'en' ? 'Passport Verified' : 'ಪಾಸ್‌ಪೋರ್ಟ್ ಪರಿಶೀಲಿಸಲಾಗಿದೆ')
                : (language === 'en' ? 'Digital Check-in' : 'ಡಿಜಿಟಲ್ ಚೆಕ್-ಇನ್')}
            </span>
          </button>
        </div>

        {/* Content Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-10 text-heritage-stone">
            <section>
              <div className="flex items-center gap-3 text-heritage-ochre mb-4">
                <div className="w-8 h-px bg-heritage-gold" />
                <h2 className="text-xs uppercase tracking-[0.3em] font-black">History & Architecture</h2>
              </div>
              <p className="font-serif text-2xl leading-relaxed italic text-heritage-ochre mb-6">
                {site.description[language]}
              </p>
              <div className="bg-heritage-secondary p-6 border-l-4 border-heritage-gold shadow-sm">
                <p className="text-sm font-bold uppercase tracking-widest text-heritage-stone mb-2">Expert Note:</p>
                <p className="text-heritage-stone leading-relaxed">
                  {site.legend[language]}
                </p>
              </div>
            </section>
          </div>

          <aside className="space-y-6">
            <AnimatePresence>
              {unlockedFact && site.hiddenFact && (
                <motion.div 
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="bg-white p-6 border border-heritage-gold shadow-xl relative overflow-hidden"
                >
                  <div className="absolute -right-4 -bottom-4 text-6xl opacity-10 grayscale">📜</div>
                  <div className="flex items-center gap-2 text-heritage-gold mb-3">
                    <Sparkles size={18} />
                    <h2 className="text-[10px] uppercase tracking-[0.2em] font-black">Hidden Fact Unlocked</h2>
                  </div>
                  <p className="text-heritage-stone text-sm italic leading-relaxed relative z-10">
                    "{site.hiddenFact[language]}"
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            {!unlockedFact && (
              <div className="bg-white/50 p-6 border-2 border-dashed border-heritage-muted flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-heritage-secondary border border-heritage-muted flex items-center justify-center text-2xl mb-4 grayscale opacity-40">📷</div>
                <p className="text-xs uppercase tracking-widest font-bold text-heritage-stone/60 mb-2">Encrypted Data</p>
                <p className="text-[10px] text-heritage-stone/40 leading-relaxed uppercase tracking-tighter">
                  {language === 'en' 
                    ? 'Scan onsite QR to decrypt hidden facts' 
                    : 'ರಹಸ್ಯ ಮಾಹಿತಿ ತಿಳಿಯಲು ದೃಢೀಕೃತ ಕ್ಯೂಆರ್ ಸ್ಕ್ಯಾನ್ ಮಾಡಿ'}
                </p>
              </div>
            )}
            
            <div className="p-6 bg-heritage-stone text-heritage-sand">
              <h3 className="text-[10px] uppercase tracking-widest font-bold mb-4 border-b border-heritage-sand/20 pb-2">Technical Specs</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-[10px]">
                  <span className="opacity-60">Era</span>
                  <span>Classic Period</span>
                </div>
                <div className="flex justify-between text-[10px]">
                  <span className="opacity-60">Material</span>
                  <span>Schist / Sandstone</span>
                </div>
                <div className="flex justify-between text-[10px]">
                  <span className="opacity-60">Accuracy</span>
                  <span>99.8% Geo-Match</span>
                </div>
              </div>
            </div>
          </aside>
        </div>

        <div className="h-20" /> {/* Spacer */}
      </div>
    </motion.div>
  );
}

function Award({ size }: { size: number }) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <circle cx="12" cy="8" r="7" />
      <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88" />
    </svg>
  );
}
