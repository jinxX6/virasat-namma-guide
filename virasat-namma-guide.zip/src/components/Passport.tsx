import React from 'react';
import { HeritageSite } from '../data/sites';
import { Award, Calendar, MapPin } from 'lucide-react';
import { motion } from 'motion/react';

interface PassportProps {
  visitedSiteIds: string[];
  sites: HeritageSite[];
  language: 'en' | 'kn';
}

export default function Passport({ visitedSiteIds, sites, language }: PassportProps) {
  const visitedSites = sites.filter(s => visitedSiteIds.includes(s.id));
  
  return (
    <div className="max-w-4xl mx-auto py-12 px-6">
      <div className="text-center mb-12 border-b border-heritage-gold/30 pb-8">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="inline-block p-6 bg-heritage-gold text-white rounded-sm mb-6 shadow-2xl"
        >
          <Award size={64} strokeWidth={1} />
        </motion.div>
        <h1 className="font-serif text-5xl text-heritage-stone mb-4 tracking-tight">
          {language === 'en' ? 'Heritage Passport' : 'ಪರಂಪರೆ ಪಾಸ್‌ಪೋರ್ಟ್'}
        </h1>
        <div className="flex items-center justify-center gap-4 text-heritage-stone uppercase tracking-[0.2em] text-[10px] font-bold">
          <span className="opacity-60 text-heritage-ochre uppercase tracking-widest">{language === 'en' ? 'Status: Explorer' : 'ಸ್ಥಿತಿ: ಅನ್ವೇಷಕ'}</span>
          <div className="w-1.5 h-1.5 bg-heritage-gold rounded-full" />
          <span className="text-heritage-gold">{visitedSites.length} / {sites.length} {language === 'en' ? 'Authentic Signatures' : 'ಅಧಿಕೃತ ಸಹಿಗಳು'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {visitedSites.length > 0 ? (
          visitedSites.map((site, index) => (
            <motion.div
              key={site.id}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white border-2 border-heritage-muted p-8 shadow-xl relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-heritage-gold/5 -mr-8 -mt-8 rounded-full transition-transform group-hover:scale-150" />
              <div className="flex gap-6 items-start relative z-10">
                <div className="w-20 h-20 rounded-sm overflow-hidden flex-shrink-0 border-4 border-white shadow-md">
                  <img src={site.image} alt={site.name[language]} className="w-full h-full object-cover grayscale" />
                </div>
                <div>
                  <h3 className="font-serif text-2xl text-heritage-stone mb-2">{site.name[language]}</h3>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-heritage-stone/60 font-bold">
                      <MapPin size={12} />
                      <span>{site.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-heritage-stone/60 font-bold">
                      <Calendar size={12} />
                      <span>{new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                    </div>
                  </div>
                  <div className="mt-6 inline-flex items-center gap-2 px-3 py-1 bg-heritage-gold text-white text-[9px] font-black uppercase tracking-[0.2em] shadow-sm">
                    Verified Entry
                  </div>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full py-20 text-center border-2 border-dashed border-heritage-muted bg-white/30">
            <p className="font-serif text-2xl text-heritage-stone opacity-30 italic">
              {language === 'en' ? 'Awaiting your first discovery...' : 'ನಿಮ್ಮ ಮೊದಲ ಅನ್ವೇಷಣೆಗಾಗಿ ಕಾಯುತ್ತಿದ್ದೇವೆ...'}
            </p>
          </div>
        )}
      </div>

      {/* Badges Section */}
      <div className="mt-20">
        <div className="flex items-center gap-4 mb-10">
          <h2 className="text-xs uppercase tracking-[0.3em] font-black text-heritage-ochre">Honorary Distinctions</h2>
          <div className="flex-1 h-px bg-heritage-gold/20" />
        </div>
        <div className="flex flex-wrap gap-12 justify-center">
          {[
            { id: 'pioneer', name: 'Pioneer', icon: '🏛️', min: 1, desc: 'First Site Visit' },
            { id: 'chronicler', name: 'Chronicler', icon: '📜', min: 3, desc: '3 Sites Documented' },
            { id: 'guardian', name: 'Guardian', icon: '🐘', min: 5, desc: 'Heritage Protector' },
          ].map(badge => {
            const earned = visitedSites.length >= badge.min;
            return (
              <div key={badge.id} className={`flex flex-col items-center group transition-all ${!earned && 'opacity-20 grayscale'}`}>
                <div className={`w-28 h-28 border-4 ${earned ? 'border-heritage-gold bg-heritage-gold/10' : 'border-heritage-muted bg-transparent'} flex items-center justify-center text-5xl mb-4 transition-all duration-500 group-hover:rotate-12`}>
                  {badge.icon}
                </div>
                <span className="text-xs font-black uppercase tracking-[0.2em] text-heritage-stone mb-1">{badge.name}</span>
                <span className="text-[10px] text-heritage-ochre uppercase font-bold tracking-tighter opacity-60">{badge.desc}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
