import React, { useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { X } from 'lucide-react';

interface ScannerProps {
  onScan: (decodedText: string) => void;
  onClose: () => void;
}

export default function Scanner({ onScan, onClose }: ScannerProps) {
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  useEffect(() => {
    scannerRef.current = new Html5QrcodeScanner(
      "reader",
      { fps: 10, qrbox: { width: 250, height: 250 } },
      /* verbose= */ false
    );

    scannerRef.current.render(onScan, (error) => {
      // Quiet fail for scan errors (it happens many times a second)
    });

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear().catch(error => {
          console.error("Failed to clear html5QrcodeScanner. ", error);
        });
      }
    };
  }, [onScan]);

  return (
    <div className="fixed inset-0 z-50 bg-heritage-dark/95 backdrop-blur-sm flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-lg relative bg-heritage-sand overflow-hidden temple-border p-8 shadow-2xl">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-heritage-stone text-heritage-sand rounded-sm z-10 hover:bg-heritage-gold transition-colors"
        >
          <X size={20} />
        </button>
        
        <div className="mb-8 text-center border-b border-heritage-muted pb-6">
          <div className="w-12 h-12 bg-heritage-gold/10 border border-heritage-gold flex items-center justify-center text-2xl mx-auto mb-4">📷</div>
          <h2 className="text-[10px] uppercase tracking-[0.3em] font-black text-heritage-ochre mb-2">Authenticated Scanner</h2>
          <h1 className="font-serif text-3xl text-heritage-stone">Archives Discovery</h1>
          <p className="text-[10px] text-heritage-stone/40 uppercase tracking-widest mt-2">Position the artifact code within the frame</p>
        </div>

        <div id="reader" className="w-full border-2 border-heritage-muted shadow-inner overflow-hidden rounded-sm"></div>
        
        <div className="mt-8 flex items-center justify-between pointer-events-none opacity-40">
          <div className="text-[9px] uppercase tracking-widest text-heritage-stone">Sensor: Active</div>
          <div className="text-[9px] uppercase tracking-widest text-heritage-stone">Auth: 256-Bit</div>
          <div className="text-[9px] uppercase tracking-widest text-heritage-stone">Signal: 4/4</div>
        </div>
      </div>
    </div>
  );
}
