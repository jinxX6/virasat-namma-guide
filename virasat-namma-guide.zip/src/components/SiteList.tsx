import React from 'react';
import { HeritageSite } from '../data/sites';
import { MapPin, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface SiteListProps {
  sites: HeritageSite[];
  onSelect: (site: HeritageSite) => void;
  language: 'en' | 'kn';
}

export default function SiteList({ sites, onSelect, language }: SiteListProps) {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4 border-b border-heritage-muted pb-6">
        <div>
          <h2 className="text-xs uppercase tracking-[0.2em] text-heritage-ochre font-bold mb-3">Nearby Hidden Gems</h2>
          <h1 className="font-serif text-4xl text-heritage-stone">
            {language === 'en' ? 'Gateway to History' : 'ಇತಿಹಾಸದ ದ್ವಾರ'}
          </h1>
        </div>
        <div className="px-4 py-2 bg-heritage-gold text-white text-[10px] font-bold uppercase tracking-widest shadow-lg">
          {sites.length} {language === 'en' ? 'Sites Discovered' : 'ತಾಣಗಳು ಪತ್ತೆಯಾಗಿವೆ'}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        {sites.map((site, index) => (
          <motion.div
            key={site.id}
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -8 }}
            onClick={() => onSelect(site)}
            className="group cursor-pointer bg-white overflow-hidden shadow-xl hover:shadow-2xl transition-all border border-heritage-muted"
          >
            <div className="relative h-64 overflow-hidden border-b-4 border-heritage-gold">
              <img 
                src={site.image} 
                alt={site.name[language]} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale-[30%] group-hover:grayscale-0"
              />
              <div className="absolute top-0 right-0 px-4 py-2 bg-heritage-gold text-white text-[10px] font-bold uppercase tracking-widest">
                {site.category}
              </div>
            </div>
            <div className="p-8">
              <div className="flex items-center gap-1 text-heritage-gold mb-3 text-[10px] font-bold uppercase tracking-[0.1em]">
                <MapPin size={12} />
                <span>{site.distance} • {site.location}</span>
              </div>
              <h3 className="font-serif text-3xl text-heritage-stone mb-4 leading-tight group-hover:text-heritage-gold transition-colors">
                {site.name[language]}
              </h3>
              <p className="text-sm text-heritage-ochre line-clamp-2 mb-6 italic opacity-80 leading-relaxed">
                {site.description[language]}
              </p>
              <div className="flex items-center gap-3 text-heritage-stone font-bold text-[10px] uppercase tracking-[0.2em] pt-4 border-t border-heritage-muted group-hover:text-heritage-gold transition-colors">
                <span>{language === 'en' ? 'Access Archives' : 'ದಾಖಲೆಗಳನ್ನು ವೀಕ್ಷಿಸಿ'}</span>
                <ArrowRight size={14} className="transition-transform group-hover:translate-x-2" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
