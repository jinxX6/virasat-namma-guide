/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { SITES, HeritageSite } from './data/sites';
import SiteList from './components/SiteList';
import SiteDetail from './components/SiteDetail';
import Scanner from './components/Scanner';
import Passport from './components/Passport';
import { Compass, Scan, Award, Languages } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type View = 'discovery' | 'passport';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('discovery');
  const [selectedSite, setSelectedSite] = useState<HeritageSite | null>(null);
  const [showScanner, setShowScanner] = useState(false);
  const [language, setLanguage] = useState<'en' | 'kn'>('en');
  const [visitedSiteIds, setVisitedSiteIds] = useState<string[]>([]);
  const [unlockedFactIds, setUnlockedFactIds] = useState<string[]>([]);

  // Load from LocalStorage
  useEffect(() => {
    const savedVisited = localStorage.getItem('visitedSites');
    const savedUnlocked = localStorage.getItem('unlockedFacts');
    if (savedVisited) setVisitedSiteIds(JSON.parse(savedVisited));
    if (savedUnlocked) setUnlockedFactIds(JSON.parse(savedUnlocked));
  }, []);

  // Save to LocalStorage
  useEffect(() => {
    localStorage.setItem('visitedSites', JSON.stringify(visitedSiteIds));
  }, [visitedSiteIds]);

  useEffect(() => {
    localStorage.setItem('unlockedFacts', JSON.stringify(unlockedFactIds));
  }, [unlockedFactIds]);

  const handleCheckIn = (siteId: string) => {
    if (!visitedSiteIds.includes(siteId)) {
      setVisitedSiteIds([...visitedSiteIds, siteId]);
    }
  };

  const handleScanSuccess = (siteId: string) => {
    setShowScanner(false);
    // Find the site
    const site = SITES.find(s => s.id === siteId);
    if (site) {
      setSelectedSite(site);
      if (!unlockedFactIds.includes(siteId)) {
        setUnlockedFactIds([...unlockedFactIds, siteId]);
      }
    } else {
      alert(language === 'en' ? "Unknown Heritage ID" : "ಅಜ್ಞಾತ ಹೆರಿಟೇಜ್ ಐಡಿ");
    }
  };

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'kn' : 'en');
  };

  return (
    <div className="min-h-screen bg-heritage-sand font-sans flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-heritage-stone text-heritage-sand border-b-4 border-heritage-gold px-6 py-4 flex justify-between items-center shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-heritage-gold text-white rounded-sm flex items-center justify-center text-2xl shadow-inner">
            🏛️
          </div>
          <div>
            <h1 className="font-serif text-2xl font-bold tracking-tight text-heritage-sand uppercase">Virasat-Namma</h1>
            <p className="text-[10px] uppercase tracking-[0.2em] text-heritage-gold/80 font-bold">Digital Heritage Passport • Karnataka</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleLanguage}
            className="flex items-center bg-heritage-dark/50 border border-heritage-ochre rounded overflow-hidden"
          >
            <span className={`px-3 py-1 text-[10px] font-bold ${language === 'en' ? 'bg-heritage-gold text-white' : 'text-heritage-sand/60'}`}>ENG</span>
            <span className={`px-3 py-1 text-[10px] font-bold ${language === 'kn' ? 'bg-heritage-gold text-white' : 'text-heritage-sand/60'} kannada-text`}>ಕನ್ನಡ</span>
          </button>
          
          <div className="hidden md:flex flex-col items-end">
            <span className="text-[10px] uppercase opacity-60 tracking-widest">Progress</span>
            <span className="text-xs font-bold text-heritage-gold">{visitedSiteIds.length} / {SITES.length} Sites</span>
          </div>
        </div>
      </header>

      <main className="pb-24">
        {/* Hero Section (Only on discovery) */}
        {currentView === 'discovery' && !selectedSite && (
          <section className="relative h-[40vh] min-h-[300px] flex flex-col items-center justify-center text-center p-6 bg-heritage-stone overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1590050752117-23a9d7fc24b8?q=80&w=2000&auto=format&fit=crop" 
              className="absolute inset-0 w-full h-full object-cover opacity-40"
              alt="Hampi"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-heritage-stone/50 to-heritage-stone" />
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="relative z-10 max-w-2xl"
            >
              <h2 className="font-serif text-4xl md:text-6xl text-heritage-sand mb-4">
                {language === 'en' ? "Karnataka's Hidden Stories" : "ಕರ್ನಾಟಕದ ಗುಪ್ತ ಕಥೆಗಳು"}
              </h2>
              <p className="text-heritage-sand/80 text-lg md:text-xl italic">
                {language === 'en' 
                  ? "Explore the forgotten temples, inscriptions, and legends of the land."
                  : "ನಾಡಿನ ಮರೆತುಹೋದ ದೇವಾಲಯಗಳು, ಶಾಸನಗಳು ಮತ್ತು ದಂತಕಥೆಗಳನ್ನು ಅನ್ವೇಷಿಸಿ."}
              </p>
            </motion.div>
          </section>
        )}

        {/* Content based on view */}
        <div className="relative">
          {currentView === 'discovery' ? (
            <SiteList 
              sites={SITES} 
              onSelect={setSelectedSite} 
              language={language} 
            />
          ) : (
            <Passport 
              visitedSiteIds={visitedSiteIds} 
              sites={SITES} 
              language={language}
            />
          )}
        </div>
      </main>

      {/* Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-heritage-stone border-t-2 border-heritage-gold px-8 py-3 z-30 pb-safe shadow-2xl">
        <div className="max-w-md mx-auto flex justify-between items-center relative">
          <button 
            onClick={() => setCurrentView('discovery')}
            className={`flex flex-col items-center gap-1 transition-all ${currentView === 'discovery' ? 'text-heritage-gold scale-110' : 'text-heritage-sand/40'}`}
          >
            <Compass size={24} strokeWidth={currentView === 'discovery' ? 2.5 : 2} />
            <span className="text-[10px] font-bold uppercase tracking-[0.1em]">Discovery</span>
          </button>

          <button 
            onClick={() => setShowScanner(true)}
            className="flex flex-col items-center -mt-12 bg-heritage-gold text-white p-4 rounded shadow-lg shadow-black/40 border-4 border-heritage-stone hover:scale-105 transition-transform"
          >
            <Scan size={32} />
          </button>

          <button 
            onClick={() => setCurrentView('passport')}
            className={`flex flex-col items-center gap-1 transition-all ${currentView === 'passport' ? 'text-heritage-gold scale-110' : 'text-heritage-sand/40'}`}
          >
            <Award size={24} strokeWidth={currentView === 'passport' ? 2.5 : 2} />
            <span className="text-[10px] font-bold uppercase tracking-[0.1em]">Passport</span>
          </button>
        </div>
      </nav>

      {/* Footer / Status Bar (Desktop only or as small detail) */}
      <footer className="hidden md:flex fixed bottom-0 left-0 right-0 h-6 bg-heritage-dark text-heritage-ochre px-4 items-center justify-between text-[9px] uppercase tracking-[0.2em] z-40">
        <span>ML Kit Scanner: Active</span>
        <span>Virasat-Namma v1.2.0 • Karnataka Tourism</span>
        <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" /> Location: High Accuracy</span>
      </footer>

      {/* Overlays */}
      <AnimatePresence>
        {selectedSite && (
          <SiteDetail 
            site={selectedSite} 
            onClose={() => setSelectedSite(null)}
            onCheckIn={handleCheckIn}
            isVisited={visitedSiteIds.includes(selectedSite.id)}
            unlockedFact={unlockedFactIds.includes(selectedSite.id)}
            language={language}
          />
        )}
        {showScanner && (
          <Scanner 
            onScan={handleScanSuccess} 
            onClose={() => setShowScanner(false)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

