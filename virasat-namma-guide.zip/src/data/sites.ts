export interface HeritageSite {
  id: string;
  name: {
    en: string;
    kn: string;
  };
  location: string;
  distance: string;
  description: {
    en: string;
    kn: string;
  };
  legend: {
    en: string;
    kn: string;
  };
  image: string;
  audioUrl: string;
  category: 'temple' | 'inscription' | 'monument';
  hiddenFact?: {
    en: string;
    kn: string;
  };
}

export const SITES: HeritageSite[] = [
  {
    id: 'halmidi-01',
    name: {
      en: 'Halmidi Inscription Site',
      kn: 'ಹಲ್ಮಿಡಿ ಶಾಸನ ತಾಣ',
    },
    location: 'Hassan District',
    distance: '3.2 km',
    category: 'inscription',
    description: {
      en: 'The site of the earliest known Kannada inscription, dating back to 450 AD. It marks a crucial point in the evolution of the Kannada language.',
      kn: 'ಕ್ರಿ.ಶ.೪೫೦ರ ಕಾಲದ ಅತ್ಯಂತ ಹಳೆಯ ಕನ್ನಡ ಶಾಸನ ದೊರೆತ ಸ್ಥಳ. ಇದು ಕನ್ನಡ ಭಾಷೆಯ ಉಗಮದ ಪ್ರಮುಖ ಹಂತವಾಗಿದೆ.',
    },
    legend: {
      en: 'Local legends say the stone was preserved by the village elders for generations before its historical significance was realized by archaeologists.',
      kn: 'ಈ ಶಾಸನದ ಐತಿಹಾಸಿಕ ಮಹತ್ವವನ್ನು ಪುರಾತತ್ವ ಶಾಸ್ತ್ರಜ್ಞರು ಗುರುತಿಸುವ ಮೊದಲು, ಗ್ರಾಮದ ಹಿರಿಯರು ಇದನ್ನು ತಲೆಮಾರುಗಳಿಂದ ಸಂರಕ್ಷಿಸಿಕೊಂಡು ಬಂದಿದ್ದರು ಎಂಬ ನಂಬಿಕೆಯಿದೆ.',
    },
    image: 'https://images.unsplash.com/photo-1590732487824-4ce1f362463e?q=80&w=1000&auto=format&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    hiddenFact: {
      en: 'The inscription contains 16 lines written in archaic Kannada script (Purvada Halegannada).',
      kn: 'ಈ ಶಾಸನವು ಪೂರ್ವದ ಹಳಗನ್ನಡ ಲಿಪಿಯಲ್ಲಿ ಬರೆದ ೧೬ ಸಾಲುಗಳನ್ನು ಹೊಂದಿದೆ.',
    },
  },
  {
    id: 'kavaledurga-02',
    name: {
      en: 'Kavaledurga Fort & Temple',
      kn: 'ಕವಲೇದುರ್ಗ ಕೋಟೆ ಮತ್ತು ದೇವಾಲಯ',
    },
    location: 'Shimoga District',
    distance: '8.5 km',
    category: 'monument',
    description: {
      en: 'A 9th-century fort hidden deep in the Western Ghats, featuring a beautiful temple dedicated to Sri Sringereshwara. It was a secondary capital for the Keladi Nayakas.',
      kn: 'ಪಶ್ಚಿಮ ಘಟ್ಟಗಳ ಆಳದಲ್ಲಿ ಅಡಗಿರುವ ೯ನೇ ಶತಮಾನದ ಕೋಟೆ. ಇಲ್ಲಿ ಶ್ರೀ ಶೃಂಗೇರೇಶ್ವರನಿಗೆ ಅರ್ಪಿತವಾದ ಸುಂದರ ದೇವಾಲಯವಿದೆ. ಇದು ಕೆಳದಿ ನಾಯಕರ ಎರಡನೇ ರಾಜಧಾನಿಯಾಗಿತ್ತು.',
    },
    legend: {
      en: 'It is believed that the fort was built to be impenetrable, with seven layers of stone walls designed to look like part of the natural hillock.',
      kn: 'ಈ ಕೋಟೆಯನ್ನು ಭೇದಿಸಲಾಗದಂತೆ ನಿರ್ಮಿಸಲಾಗಿತ್ತು ಎಂದು ನಂಬಲಾಗಿದೆ, ನೈಸರ್ಗಿಕ ಬೆಟ್ಟದಂತೆಯೇ ಕಾಣುವಂತೆ ಏಳು ಪದರಗಳ ಕಲ್ಲಿನ ಗೋಡೆಗಳನ್ನು ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿತ್ತು.',
    },
    image: 'https://images.unsplash.com/photo-1624458315147-3be665a04ac6?q=80&w=1000&auto=format&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    hiddenFact: {
      en: 'The fort has a secret underground water system that never runs dry even in peak summer.',
      kn: 'ಕೋಟೆಯು ರಹಸ್ಯ ಅಂತರ್ಜಲ ವ್ಯವಸ್ಥೆಯನ್ನು ಹೊಂದಿದ್ದು, ಬೇಸಿಗೆಯಲ್ಲೂ ಇದು ಎಂದಿಗೂ ಬತ್ತುವುದಿಲ್ಲ.',
    },
  },
  {
    id: 'shravanabelagola-03',
    name: {
      en: 'Chandragiri Hill Inscriptions',
      kn: 'ಚಂದ್ರಗಿರಿ ಬೆಟ್ಟದ ಶಾಸನಗಳು',
    },
    location: 'Hassan District',
    distance: '12.0 km',
    category: 'inscription',
    description: {
      en: 'While most visit the big statue, Chandragiri houses over 800 inscriptions detailing the lives of monks and kings from the 6th century onwards.',
      kn: 'ಹೆಚ್ಚಿನವರು ದೊಡ್ಡ ಪ್ರತಿಮೆಯನ್ನು ನೋಡಲು ಬರುತ್ತಾರಾದರೂ, ಚಂದ್ರಗಿರಿಯಲ್ಲಿ ೬ನೇ ಶತಮಾನದ ನಂತರದ ಸನ್ಯಾಸಿಗಳು ಮತ್ತು ರಾಜರ ಜೀವನದ ಬಗ್ಗೆ ವಿವರಿಸುವ ೮೦೦ಕ್ಕೂ ಹೆಚ್ಚು ಶಾಸನಗಳಿವೆ.',
    },
    legend: {
      en: 'Chandragupta Maurya and his guru Bhadrabahu are said to have spent their final days here in meditation.',
      kn: 'ಚಂದ್ರಗುಪ್ತ ಮೌರ್ಯ ಮತ್ತು ಅವನ ಗುರು ಭದ್ರಬಾಹು ತಮ್ಮ ಕೊನೆಯ ದಿನಗಳನ್ನು ಇಲ್ಲಿ ಧ್ಯಾನದಲ್ಲಿ ಕಳೆದರು ಎಂದು ಹೇಳಲಾಗುತ್ತದೆ.',
    },
    image: 'https://images.unsplash.com/photo-1548013146-72479768bbaa?q=80&w=1000&auto=format&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    hiddenFact: {
      en: 'One of the inscriptions describes the ritual of Sallekhana, a voluntary fasting to death practised by Jain monks.',
      kn: 'ಒಂದು ಶಾಸನವು ಜೈನ ಸನ್ಯಾಸಿಗಳು ಅನುಸರಿಸುವ ಸಲ್ಲೇಖನ ವ್ರತದ ಬಗ್ಗೆ ವಿವರಿಸುತ್ತದೆ.',
    },
  },
];
